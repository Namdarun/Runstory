-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8A806.p.ssafy.io    Database: runstory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `running`
--

DROP TABLE IF EXISTS `running`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `running` (
  `running_id` bigint NOT NULL AUTO_INCREMENT,
  `crew_name` varchar(50) NOT NULL COMMENT '러닝 제목',
  `distance` float NOT NULL COMMENT '거리',
  `end_latitude` float NOT NULL COMMENT '종료 위치 위도',
  `end_location` varchar(100) NOT NULL COMMENT '러닝 종료 위치',
  `end_longitude` float NOT NULL COMMENT '종료 위치 경도',
  `end_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '종료 시간',
  `img_file_name` varchar(500) NOT NULL COMMENT '이미지 파일 이름',
  `img_file_path` varchar(500) NOT NULL COMMENT '이미지 파일 경로',
  `is_finished` tinyint(1) DEFAULT '0' COMMENT '종료 여부',
  `regdate` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성일자',
  `running_content` varchar(1000) NOT NULL COMMENT '러닝 내용',
  `start_latitude` float NOT NULL COMMENT '시작 위치 위도',
  `start_location` varchar(100) NOT NULL COMMENT '러닝 시작 위치',
  `start_longitude` float NOT NULL COMMENT '시작 위치 경도',
  `start_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '시작 시간',
  `user_id` bigint DEFAULT NULL COMMENT '생성자',
  PRIMARY KEY (`running_id`),
  KEY `FKf62myi3cec1wmjrcr1xuffnm8` (`user_id`),
  CONSTRAINT `FKf62myi3cec1wmjrcr1xuffnm8` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `running`
--

LOCK TABLES `running` WRITE;
/*!40000 ALTER TABLE `running` DISABLE KEYS */;
INSERT INTO `running` VALUES (4,'치타보다 빠른 사람들',12064,37.5643,'신도멀티프라자',126.96,'2023-02-15 16:49:57','d6491749-1551-4c2b-9e43-afafb61d46a5경로 이미지.png','/var/lib/runstory/running/',1,'2023-02-15 16:49:57','한번 뛰어볼려?',37.6256,'공릉역[7호선]',127.073,'2023-02-15 16:49:57',2),(7,'싸피 8기 모여~~~',1997,37.5118,'코엑스',127.058,'2023-02-16 00:02:38','619b7668-99c1-49eb-a2df-61fde01607d53D1C8F16-6973-4525-A64F-9F9DFC017943.jpeg','/var/lib/runstory/running/',1,'2023-02-16 00:02:38','건강챙기면서 개발하실 8기 싸피분들 모집합니다~~\r\n특화 프로젝트도 화이팅!!??',37.5012,'멀티캠퍼스 교육센터',127.039,'2023-02-16 00:02:38',5),(10,'러닝크루',171,37.5552,'신촌역[2호선]',126.937,'2023-02-16 09:52:42','52c0fae8-54fc-4dfe-80f9-a1557fe7c2d8loginByPutty.png','/var/lib/runstory/running/',1,'2023-02-16 09:52:42','ㅇㅇ',37.5553,'삼성멀티캠퍼스 신촌점',126.939,'2023-02-16 09:52:42',5),(14,'여의도 한바퀴',8777,37.5223,'여의도한강공원',126.941,'2023-02-16 21:21:00','aa263dac-b57c-4eec-99c7-e3b680b6d0efyeouido3.jpg','/var/lib/runstory/running/',1,'2023-02-16 11:20:16','돌자잇!!!!!',37.5007,'역삼역[2호선]',127.036,'2023-02-16 20:20:00',5),(23,'강남에서 역삼까지',852,37.5007,'역삼역[2호선]',127.036,'2023-02-18 03:48:00','63820ba2-16de-44f1-8e3b-d8929dab736c경로 이미지 (2).png','/var/lib/runstory/running/',0,'2023-02-16 17:47:14','뛰어봅시다! ',37.4972,'강남역[2호선]',127.028,'2023-02-18 02:47:00',9),(24,'수원러너',1324,37.2848,'광교호수공원 제3주차장',127.077,'2023-02-17 08:31:00','802dc09e-9602-4540-966c-9d71a516ba85rr.jpg','/var/lib/runstory/running/',1,'2023-02-16 19:30:33','광교호수공원 뛰실분 모집합니다!',37.2764,'광교호수공원',127.066,'2023-02-17 07:30:00',8),(25,'시숲러너',3145,37.4972,'강남역[2호선]',127.028,'2023-02-18 08:50:00','07e4b500-db5c-4c39-8fb1-f3da58afb70ayangjae.jpg','/var/lib/runstory/running/',0,'2023-02-16 19:45:59','양재시민의 숲에서 함께 뛰어보실분 있나요?',37.4702,'양재시민의숲역[신분당선]',127.038,'2023-02-18 05:45:00',8),(26,'강남역삼팟',852,37.5007,'역삼역[2호선]',127.036,'2023-02-19 21:03:00','d2623842-5a22-43c1-ad27-27126dc8d081경로 이미지 (1).png','/var/lib/runstory/running/',0,'2023-02-16 21:04:12','경험치 쌓자!!!',37.4972,'강남역[2호선]',127.028,'2023-02-20 06:03:00',9),(27,'뛰뛰러너',15202,37.5007,'역삼역[2호선]',127.036,'2023-02-17 09:00:00','be3f547e-91a9-4674-bec4-5ffdc2a6a9fbcrew.jpg','/var/lib/runstory/running/',0,'2023-02-16 21:13:19','어디든 같이 뛰실 분 모집합니다!! 이번 금요일엔 상암에서 역삼으로 뜁니다!',37.5786,'마포구 상암동',126.895,'2023-02-17 14:00:00',8),(30,'인천대공원 모집',1606,37.4595,'인천대공원 동문',126.768,'2023-02-22 22:00:00','08e070be-58c1-4cbb-950e-c7d025085d40경로 이미지 (3).png','/var/lib/runstory/running/',0,'2023-02-17 03:27:37','고고!',37.4592,'인천대공원 정문',126.75,'2023-02-22 09:30:00',9),(31,'산책',1413,37.522,'여의도역[9호선]',126.925,'2023-02-17 18:00:00','edac95a7-f7e4-483b-92a2-7e8a4dcbda05B00B6C5A-57AF-4C2A-8736-B9CF356E0837.jpeg','/var/lib/runstory/running/',0,'2023-02-17 08:02:30','공원에서 가볍게 뛰실 분 구합니다!!\r\n친하게 지내요~~\r\n여자분들만 와주세요',37.5223,'여의도한강공원',126.941,'2023-02-17 17:02:00',12),(32,'누구보다 빠르게',1325,37.5073,'선정릉',127.052,'2023-02-17 05:00:00','7d568f0c-f69d-479a-b59d-99c57a7b8ea5B16B70A0-6BFD-459B-AADB-9D2AC8AEF434.jpeg','/var/lib/runstory/running/',1,'2023-02-17 08:07:10','퇴근하고 뛰는 정기적인 모임이 됐으면 좋겠어요!!\r\n모두 연령대 상관없이 환영입니다?',37.5012,'멀티캠퍼스 교육센터',127.039,'2023-02-17 03:30:00',12),(33,'등록 테스트',0,37.5007,'강남구 역삼동',127.037,'2023-02-16 10:10:00','aee100b9-3c24-4096-bd41-2f4f8d1b0825꼬리야.jpg','C:/runTogether/uploads/running/',1,'2023-02-17 09:10:00','ㅇㄹㅇㄹ',37.5007,'강남구 역삼동',127.037,'2023-02-16 09:09:00',19),(34,'ㅇㅇ',0,37.5007,'강남구 역삼동',127.037,'2023-02-16 22:43:00','272156b5-c7eb-4fbc-af9d-74bd985025cc꼬리야.jpg','C:/runTogether/uploads/running/',1,'2023-02-17 09:42:33','ㅇㅇ',37.5007,'강남구 역삼동',127.037,'2023-02-16 21:42:00',19),(35,'오늘마감',0,37.5007,'강남구 역삼동',127.037,'2023-02-17 10:44:00','28b87d00-3dea-447f-9362-d13c3de62ef56c398c0fc7d20c93a3bbec23acbc47bd.jpg','C:/runTogether/uploads/running/',1,'2023-02-17 09:43:54','ㄹㅇㄴㄹㅇㄹ',37.5007,'강남구 역삼동',127.037,'2023-02-17 10:00:00',19),(36,'어제',0,37.5007,'강남구 역삼동',127.037,'2023-02-16 19:58:00','8a150470-0361-40c3-a334-d42c0444b3d0KakaoTalk_20230216_135717667_01.jpg','C:/runTogether/uploads/running/',1,'2023-02-17 09:57:09','테스트',37.5007,'강남구 역삼동',127.037,'2023-02-16 18:57:00',19),(37,'오늘마감',0,37.5007,'강남구 역삼동',127.037,'2023-02-16 11:57:00','189959bb-e346-489f-93af-0be65c3553f3d8d81f1421b88648535b0a6656a221d7.jpg','/var/lib/runstory/running/',1,'2023-02-17 10:57:08','온륵마가망',37.5007,'강남구 역삼동',127.037,'2023-02-16 10:56:00',19),(38,'0217',2201,37.5118,'코엑스',127.058,'2023-02-17 11:59:00','7976f0c0-3648-4b48-89a0-6437d2293e6b6b00420cecd7a311bf2819a8c6649170.jpg','/var/lib/runstory/running/',1,'2023-02-17 10:59:34','ㅇㄹㅇㄹ',37.5007,'강남구 역삼동',127.037,'2023-02-17 10:59:00',19),(39,'멀티캠퍼스 앞에서 만나요',1997,37.5118,'코엑스',127.058,'2023-02-16 11:59:00','c2f6e2c1-e680-4fb9-8e80-e2ccaba4f1c51341D0444ECCB3F62A.jfif','/var/lib/runstory/running/',1,'2023-02-17 11:02:22','우와 같이 달려봐요!!',37.5012,'멀티캠퍼스 교육센터',127.039,'2023-02-16 11:02:00',19);
/*!40000 ALTER TABLE `running` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:21:45

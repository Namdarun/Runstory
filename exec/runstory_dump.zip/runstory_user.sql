-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8A806.p.ssafy.io    Database: runstory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(200) DEFAULT NULL COMMENT '주소',
  `age` int DEFAULT NULL COMMENT '나이',
  `email_auth` tinyint(1) NOT NULL DEFAULT '0' COMMENT '이메일인증여부(TRUE: 이메일인증성공, FALSE: 이메일인증실패)',
  `experience` int DEFAULT '0' COMMENT '발걸음수(레벨이 상승하면 경험치 0으로 리셋)',
  `gender` int DEFAULT NULL COMMENT '성별(1: 남자, 2:여자)',
  `level` int DEFAULT '1' COMMENT '레벨',
  `phone_num` varchar(50) DEFAULT NULL COMMENT '전화번호',
  `profile_img_file_name` varchar(500) DEFAULT NULL COMMENT '프로필이미지파일명',
  `profile_img_file_path` varchar(500) DEFAULT NULL COMMENT '프로필이미지경로',
  `reg_type` varchar(255) NOT NULL COMMENT 'LOCAL: 일반회원가입, KAKAO: 카카오, GOOGLE: 구글, NAVER: 네이버',
  `regdate` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '회원가입일자',
  `role_type` varchar(255) NOT NULL COMMENT '역할(USER: 일반사용자, ADMIN: 관리자)',
  `token` varchar(300) DEFAULT NULL COMMENT '토큰',
  `updatedate` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '회원정보수정일자',
  `user_id` varchar(50) NOT NULL COMMENT '사용자아이디',
  `user_name` varchar(30) NOT NULL COMMENT '이름',
  `user_nickname` varchar(100) NOT NULL COMMENT '별명',
  `user_pwd` varchar(1000) NOT NULL COMMENT '비밀번호',
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `UK_a3imlf41l37utmxiquukk8ajc` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'서울 강남구 가로수길 5 (신사동)',27,1,0,1,0,'01084142241','b9f67e8e-851d-4833-862d-eb8faec5fd8320230215_165848.png','/var/lib/runstory/user/','KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjQ0MzcyOTMwIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODg2ODE5LCJpYXQiOjE2NzY1OTA4MTl9.2m9WZaqxRooQxRMC4XgQdfDAROCNM7eJt6muPU8mpQ5MSnDDcZN_s2LTUb77aYQV7i9vFzHKQZA4_5t8wwGMnw',NULL,'2644372930','태태태윤','카카오태윤쓰','$2a$10$G91u5N12rPGbyIA9gZvW3ee1NtQJtUKiT7cGF8UArno89KJUS.Ezm'),(3,NULL,0,1,0,2,0,NULL,NULL,NULL,'KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY1OTI3OTQxIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODQwMTYzLCJpYXQiOjE2NzY1NDQxNjN9.S8Go9TLPm7MOiwc-W7xPsA0RfUdK27Hzh2hZLbi_9SEiHtyARBk5gYLB1pt-twXwPZOyCtu8TcfwdPNDoQ3VCQ',NULL,'2665927941','원송희','songheew1020@naver.com','$2a$10$aT5OMhXo3D5QcA.OgUBi9OBDFcg2cCk1ODjhUe0HRjIGssLE0fcmK'),(4,'경기 수원시 장안구 수일로179번길 13 (조원동, 파란꿈아트팜어린이집)',22,1,1997,2,0,'1072274721',NULL,NULL,'LOCAL','2023-02-15 08:11:03','USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzb25naGVldzEwMjBAbmF2ZXIuY29tIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODMwNjY4LCJpYXQiOjE2NzY1MzQ2Njh9.5N6EMHnCMblR0LKUXg-Hm2f3zVCYKKPFqgfnlejiADrFFaC5EkX7Ct-3-kvpF1k8iFlKi3KcbhSR_SJres7L1Q','2023-02-15 08:11:03','songheew1020@naver.com','원송희','탕탕특공대','$2a$10$PflKgYG0PaFW3Re8xqRl2.VIc6sG3Ms2MqTVbHWgP0YbpRsV/41AO'),(5,'서울 강남구 테헤란로 212 (역삼동, 멀티캠퍼스)',27,1,0,2,0,'01072274723','745715dc-c647-432f-9a82-b3b51d8a7d0c(CTk)i9.jpg','/var/lib/runstory/user/','LOCAL','2023-02-15 08:13:41','USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzb25naGVldzEwMjBAZ21haWwuY29tIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODg3OTYwLCJpYXQiOjE2NzY1OTE5NjB9.Ows5UaoXcL5hsoVemZBRBpm9fkamdk93nVsqq9W__Xc5v9Sg_UvEDybVm1vawQHAij01aRDdysa3MS4LAcK31A','2023-02-15 08:13:41','songheew1020@gmail.com','백만송이찐다','닌자거북이','$2a$10$/Vw9GtIccUSZRhOu9e1kTusD2.qzv2y6moeuvPvD0pC7HJzbvleOG'),(8,NULL,0,1,0,2,0,NULL,'1fc60b2a-139e-4236-9964-4f772d5de31dKakaoTalk_20230113_094015206.jpg','/var/lib/runstory/user/','KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY1OTI3ODUyIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODk0ODY1LCJpYXQiOjE2NzY1OTg4NjV9.3vipWv517dWmmto_u75RDUuihd37u7W4KP4RfQ6JbcwrPZtE5uFzjBJi1o3yWNfDzCp9dcO24vWJYwc2XAOReg',NULL,'2665927852','임민수','11395945@naver.com','$2a$10$JgcG1vtwNHRN2cqjMnY4ueEy4hJ2kzBTW8K3xhFXhW0rt69hpG3nC'),(9,'null',30,1,171,1,0,'01086408814','e4183f24-867a-4491-abd4-3020cc8dc82d1676571820425.png','/var/lib/runstory/user/','KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY1MDAzNDEwIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODcxNDEwLCJpYXQiOjE2NzY1NzU0MTB9.mdxoBPD3BMIQWqeBK-iursbZmdUHcbhXubxk3-ufFajCMSg1vRixeRqoeaYSKJzP5HvPI_UejwTvKXPAJgaRzQ',NULL,'2665003410','남기성','gs20wow@naver.com','$2a$10$ANCoVfu9wQTiY1REDDv3YeTrimazRMM6VJM1gGU4.iw.eTkVnlOIq'),(11,NULL,0,1,0,2,0,NULL,NULL,NULL,'KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY3NjQ4MDQzIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODQ3ODQ2LCJpYXQiOjE2NzY1NTE4NDZ9.hnW23TXxSbmyBwctt5qO3QqWiAFPLuB2T1yuwlXtQ2ADwmcCWgUDrEaKxVXG-4xWFd3l5-ZwQ8DFDDbr1tCYQQ',NULL,'2667648043','박용찬','sdc00035@naver.com','$2a$10$OaccPJqRPh/aVEYk5zS44edNaq3U8AKaRikF0ffw2LsIEoYWFSuOy'),(12,NULL,0,1,1089,2,0,NULL,NULL,NULL,'KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjU3ODgyMzM2IiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODU0MjE3LCJpYXQiOjE2NzY1NTgyMTd9.gWqPYHZ0ZtLDaRzkVDuSlPKk-td_AgHnrlUr4ufRZ4gDdeP-pHdQ3BN6ok__mU5T-UlBUz7Yc0u6TvE70cf6qA',NULL,'2657882336','신도연','ehdus7310@gmail.com','$2a$10$TqAcftbtAUiQmajJ3cSAReL.oIOYTaTuG.YDAW6Pg22HQjBOJzLaC'),(13,NULL,0,1,16457,2,0,NULL,NULL,NULL,'KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY3NzgyNjM4IiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODUyODQ4LCJpYXQiOjE2NzY1NTY4NDh9.ZMbsWSsZ_NrgKMuaQ1xT2heuURRc_XxdzolQt1mLzdM9X_WYfjqhbTCAC_UNXhjIJ8piFu90JBHIetMscGLj2A',NULL,'2667782638','오경원','okw91@hanmail.net','$2a$10$SEKVO/0TM0KIgb0RiswTeeexxGUYyQCWy.1dwv04pi2JndI1flo9K'),(16,'서울 마포구 백범로 4 (노고산동)',29,1,0,1,0,'01086408814','abe2aca4-afe0-404d-8f60-4519af3187f5Screenshot_20230203-080528_YouTube.jpg','/var/lib/runstory/user/','LOCAL',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJnczIwd293QG5hdmVyLmNvbSIsImlzcyI6InNzYWZ5LmNvbSIsImV4cCI6MTY3Nzg4OTkwMiwiaWF0IjoxNjc2NTkzOTAyfQ.nWedrB6eZnu4Tcb5jrUJv9xbJKq4bexKrlV3ax4NF68vZTAtV_OuFrnLsTl2kOwXlmc9qzL6h8Q94Cw7JO_P7w',NULL,'gs20wow@naver.com','남기성','남다람쥐','$2a$10$rLhliiQ3pVDXRrraIf1bh.lequMb7qBL2M7NNI0Nt8UTtpRSNx3Ti'),(17,NULL,0,1,0,2,0,NULL,NULL,NULL,'KAKAO',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyNjY4NDQyNTUxIiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjc3ODE3ODAzLCJpYXQiOjE2NzY1MjE4MDN9.2kH62UsISJvNZJ9ggQO19BXXB0qqgQMouENs7aA28dlN-jf0wjT7scTLErI4fmEvt3baN5jEBO5BnlJAsCZhwg',NULL,'2668442551','곽민주','mj3544@naver.com','$2a$10$3BZrlkNmaFBt3wTMehGtFuhD55yBSd5sRNJE/KzoEshPpJlJEI7uK'),(19,'서울 강남구 테헤란로 212 (역삼동, 멀티캠퍼스)',29,1,41794,1,0,'01012341233','2085254f-7a3c-4e2f-9e4d-d57dc86b5488741d110b5e9a4972fd059f00af9e111a.jpg','/var/lib/runstory/user/','LOCAL',NULL,'USER','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJydW5zdG9yeUBnbWFpbC5jb20iLCJpc3MiOiJzc2FmeS5jb20iLCJleHAiOjE2Nzc4NjAwNzIsImlhdCI6MTY3NjU2NDA3Mn0.3YDlqEWLP6fGBfgIRNY3RH_gPVH2eVLU6PT9qa6WFN5iV-4AfVsvAceB-pv6U4tYrz99YAsj6OSHFqPUnkwfwg',NULL,'runstory@gmail.com','런스토리','runstory','$2a$10$9fnKlryuf5J5/Og2lel24uI/8NGziehw27nty2vzdyDJoEYYybkty');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:21:43

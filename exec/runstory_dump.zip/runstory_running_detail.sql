-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8A806.p.ssafy.io    Database: runstory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `running_detail`
--

DROP TABLE IF EXISTS `running_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `running_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `gender_type` varchar(255) NOT NULL,
  `has_dog` tinyint(1) NOT NULL DEFAULT '0' COMMENT '강아지 여부',
  `man` int NOT NULL DEFAULT '0' COMMENT '남자 인원',
  `max_age` int NOT NULL DEFAULT '10000000' COMMENT '최대 나이',
  `min_age` int NOT NULL DEFAULT '0' COMMENT '최소 나이',
  `total` int NOT NULL DEFAULT '0' COMMENT '총 인원',
  `women` int NOT NULL DEFAULT '0' COMMENT '여자 인원',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `running_detail`
--

LOCK TABLES `running_detail` WRITE;
/*!40000 ALTER TABLE `running_detail` DISABLE KEYS */;
INSERT INTO `running_detail` VALUES (1,'All',0,4,53,28,0,0),(2,'All',0,2,30,20,3,2),(3,'All',0,2,27,20,0,2),(4,'All',0,10,52,10,0,0),(5,'All',0,1,20,10,0,1),(6,'All',0,1,37,20,3,1),(7,'All',0,0,31,21,20,0),(8,'All',0,4,20,10,0,0),(9,'All',0,2,20,10,0,0),(10,'All',0,0,20,10,1,0),(11,'All',0,3,20,10,0,0),(12,'All',0,4,20,10,0,0),(13,'All',0,3,20,10,0,0),(14,'All',0,2,39,20,2,2),(15,'All',0,4,20,10,0,0),(16,'All',0,5,20,10,0,0),(17,'All',0,6,20,10,0,0),(18,'All',0,0,20,10,2,0),(19,'All',0,0,33,16,4,0),(20,'All',0,0,20,10,2,0),(21,'All',0,0,20,10,0,0),(22,'All',0,0,20,10,2,0),(23,'All',0,6,20,10,0,0),(24,'All',0,0,100,10,10,0),(25,'All',0,1,89,10,10,1),(26,'All',0,3,52,10,0,3),(27,'All',0,0,48,10,15,0),(30,'All',0,3,20,10,2,3),(31,'All',0,0,20,10,0,4),(32,'All',0,0,43,14,10,0),(33,'All',0,0,20,10,1,0),(34,'All',0,0,20,10,2,0),(35,'All',0,0,20,10,2,0),(36,'All',0,0,20,10,2,0),(37,'All',0,0,20,10,1,0),(38,'All',0,0,25,17,2,0),(39,'All',0,3,25,16,0,4);
/*!40000 ALTER TABLE `running_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:21:41

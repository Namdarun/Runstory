-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8A806.p.ssafy.io    Database: runstory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed_file`
--

DROP TABLE IF EXISTS `feed_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed_file` (
  `feed_file_id` bigint NOT NULL AUTO_INCREMENT COMMENT '피드 파일 아이디',
  `file_name` varchar(500) DEFAULT NULL COMMENT '파일명',
  `file_path` varchar(500) DEFAULT NULL COMMENT '파일경로',
  `feed_id` bigint DEFAULT NULL COMMENT '피드 아이디',
  PRIMARY KEY (`feed_file_id`),
  KEY `FKgf6nlc3o8dnafw24hy0iccq9s` (`feed_id`),
  CONSTRAINT `FKgf6nlc3o8dnafw24hy0iccq9s` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`feed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_file`
--

LOCK TABLES `feed_file` WRITE;
/*!40000 ALTER TABLE `feed_file` DISABLE KEYS */;
INSERT INTO `feed_file` VALUES (2,'/var/lib/runstory/feeds/','9f747d22-69c2-46e8-bf65-4ede5ce3d94520230215_165848.png',2),(4,'/var/lib/runstory/feeds/','281d86bc-cc24-4992-894e-8aa506281018BB3D0A0E-8B2C-4359-B56E-DF9993EDED77.jpeg',4),(7,'/var/lib/runstory/feeds/','5fefff04-a644-4c66-8738-cce323ce6b27566B9AED-4ABB-4347-88E3-6E8EEBBB446A.png',12),(10,'/var/lib/runstory/feeds/','b678e523-d50a-46c0-abe7-e75f96ab081e꼬리야.jpg',15),(11,'/var/lib/runstory/feeds/','4e946d3b-b625-459e-8c31-e357be622defee26cc8c2e310eb198936812abed5a55.jpeg',16),(12,'/var/lib/runstory/feeds/','22cb45f7-5fdd-4e12-b9ae-a2c154aace20abc.png',17),(13,'/var/lib/runstory/feeds/','57c4ae6f-31d9-42f2-9745-2819050225f9F0055E57-E532-47E7-A2D7-48830F574914.jpeg',18),(15,'/var/lib/runstory/feeds/','73fd6004-98ca-4fb7-a670-339cafa38994maxresdefault_(1).jpg',20),(16,'/var/lib/runstory/feeds/','923d0f9f-8823-4cb2-bfcf-a55334728123maxresdefault.jpg',21),(17,'/var/lib/runstory/feeds/','360f6f6f-599e-42de-a000-8a9bb7f361e5rhkdry.jpg',22),(18,'/var/lib/runstory/feeds/','139f9147-38cb-4958-9fc2-59a905e53183Screenshot_20230216-125737_Chrome.jpg',23),(19,'/var/lib/runstory/feeds/','6b5f9ef7-5e30-4c6c-a8fd-f4853b27d097seokchon.jpg',24),(20,'/var/lib/runstory/feeds/','d5bfb075-9196-4eab-94b4-e2fe8508a5ab경로 이미지.png',25),(22,'/var/lib/runstory/feeds/','aa300154-2eb7-4bd4-a873-655393a96512images (1).jpeg',27),(23,'/var/lib/runstory/feeds/','c6d8705c-255c-4281-9008-d35f012b3044images (2).jpeg',28),(24,'/var/lib/runstory/feeds/','7e0d7560-0908-41ad-b6be-abe7294f25f81785a83956b4cede7.png',29),(25,'/var/lib/runstory/feeds/','fe87b0cf-9ebc-4d69-beef-8197a6f95611boosan.jpg',30),(26,'/var/lib/runstory/feeds/','8bd3f2b7-d13c-4e27-a2a3-816c481ce0d8L20141025.99002234827i1.jpg',31),(27,'/var/lib/runstory/feeds/','509eef6d-485d-4d2c-8ca3-34fff172719dseoulsop.jpg',32),(28,'/var/lib/runstory/feeds/','f6fe48a7-5c9e-4676-a519-143f2b7c7109yeui.jpg',33),(29,'/var/lib/runstory/feeds/','474b0706-e317-45b6-8615-e603ec07fb81naksan.jpg',34),(30,'/var/lib/runstory/feeds/','a4068a77-60d9-41a5-add5-a592f8f10a34took.jpg',35),(31,'/var/lib/runstory/feeds/','23165834-9f1f-491c-8845-e9998f0b3e83kyungchun.jpg',36),(32,'/var/lib/runstory/feeds/','b2e59b29-d072-42c3-8df3-bb0fd9644d57new york.jpg',37),(33,'/var/lib/runstory/feeds/','15e074f6-52ec-40aa-a5ab-ec9b7f2fedf6namsan.jpg',38),(34,'/var/lib/runstory/feeds/','7a6db273-58da-400d-80bf-15f0137aa713다운로드파일-1.jpg',39),(35,'/var/lib/runstory/feeds/','9d6fe620-66cd-4177-abaa-9dc472982b3dNginx.png',40),(36,'/var/lib/runstory/feeds/','b749edcf-d429-4b93-b502-04c74e3e11201676571817203.png',41),(37,'/var/lib/runstory/feeds/','de5386fe-85fb-4280-b33b-0b764cb1d24b루피.jpg',42);
/*!40000 ALTER TABLE `feed_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:21:43

-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8A806.p.ssafy.io    Database: runstory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed` (
  `feed_id` bigint NOT NULL AUTO_INCREMENT COMMENT '피드 아이디',
  `content` varchar(1000) DEFAULT NULL COMMENT '피드 게시글 내용',
  `public_scope` varchar(255) DEFAULT NULL COMMENT '공개범위(PUBLIC: 전체공개, FRIEND: 팔로우공개, PRIVATE: 비공개)',
  `regdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedate` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_id` bigint DEFAULT NULL COMMENT '사용자 아이디',
  PRIMARY KEY (`feed_id`),
  KEY `FKeupe1ba7u2e7sr6r3fa4dhdo7` (`user_id`),
  CONSTRAINT `FKeupe1ba7u2e7sr6r3fa4dhdo7` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT INTO `feed` VALUES (2,'등산중... 한 컷...','PUBLIC','2023-02-15 17:02:57','2023-02-15 17:02:57',2),(4,'엉엉...힘들엉','PUBLIC','2023-02-15 22:56:15','2023-02-15 22:56:15',12),(12,'선릉역 산책 ?‍♂️?‍♂️','FRIEND','2023-02-16 07:54:34','2023-02-16 07:54:34',12),(15,'냥','PUBLIC','2023-02-16 10:24:53','2023-02-16 10:24:53',12),(16,'ㅠㅠ왜 시간이 이상하지','PUBLIC','2023-02-16 10:27:44','2023-02-16 10:27:44',12),(17,'404에러','PUBLIC','2023-02-16 10:52:08','2023-02-16 10:52:08',2),(18,'갱얼쥐..귀엽다리 ? ???','PUBLIC','2023-02-16 12:05:22','2023-02-16 12:05:22',12),(20,'팔로워공개 야도란~','FRIEND','2023-02-16 17:27:09','2023-02-16 17:27:09',9),(21,'래원 잘생겼다','PUBLIC','2023-02-16 17:36:51','2023-02-16 17:36:51',8),(22,'광교호수공원 한바퀴 뛰었습니다ㅎㅎ','PUBLIC','2023-02-16 19:28:17','2023-02-16 19:28:17',8),(23,'내...춥다','FRIEND','2023-02-16 19:39:15','2023-02-16 19:39:15',9),(24,'석촌호수 달리니까 좋네요~','PUBLIC','2023-02-16 19:41:24','2023-02-16 19:41:24',8),(25,'피드 작성 ㅠㅠ ','FRIEND','2023-02-16 19:43:08','2023-02-16 19:43:08',9),(27,'주먹밥 쿵야','PUBLIC','2023-02-16 19:48:53','2023-02-16 19:48:53',9),(28,'부끄러운 짱구 ','PUBLIC','2023-02-16 19:49:56','2023-02-16 19:49:56',9),(29,'성불하십쇼','PUBLIC','2023-02-16 19:50:24','2023-02-16 19:50:24',9),(30,'부산 시민공원 뛰니까 좋네요~ 부산분들 맞팔해요!','PUBLIC','2023-02-16 19:51:35','2023-02-16 19:51:35',8),(31,'집 근처 하늘공원 에서 걸었는데 억새도 이쁘고 좋아요!','PUBLIC','2023-02-16 19:54:54','2023-02-16 19:54:54',8),(32,'오랜만에 서울 숲 뛰었더니 이쁘고 상쾌하네요~','PUBLIC','2023-02-16 19:58:31','2023-02-16 19:58:31',8),(33,'여의도공원 와봤는데 공기도 상쾌하고 좋네요 다음에 같이가실분!','PUBLIC','2023-02-16 20:01:33','2023-02-16 20:01:33',8),(34,'낙산공원 처음와봤는데 진짜 분위기 너무 좋아요!','PUBLIC','2023-02-16 20:03:20','2023-02-16 20:03:20',8),(35,'뚝섬한강공원 크루분들이랑 뛰었는데 사람많고 활기차서 좋네요!','PUBLIC','2023-02-16 20:08:05','2023-02-16 20:08:05',8),(36,'경춘선 숲길 공기도 맑고 걷기 너무 좋네요! 추천입니다!','PUBLIC','2023-02-16 20:13:24','2023-02-16 20:13:24',8),(37,'친구랑 뉴욕 센트럴파크에서 걸었는데 사람 진짜 많아요!!','PUBLIC','2023-02-16 20:17:56','2023-02-16 20:17:56',8),(38,'크루분들이랑 남산 순환 산책길 걸었는데 남산타워 이쁘고 산책로 잘되어있네요 추천입니다!','PUBLIC','2023-02-16 20:25:22','2023-02-16 20:25:22',8),(39,'절겁다 절거워','PUBLIC','2023-02-16 21:00:22','2023-02-16 21:00:22',9),(40,'나는야 Ngnix 마스터~','PUBLIC','2023-02-17 00:31:02','2023-02-17 00:31:02',19),(41,'러닝 좋다','PUBLIC','2023-02-17 03:23:58','2023-02-17 03:23:58',9),(42,'루피루핑','PUBLIC','2023-02-17 08:10:48','2023-02-17 08:10:48',5);
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:21:44
